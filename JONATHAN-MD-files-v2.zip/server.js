require("dotenv").config();
const express = require("express");
const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
const TOKEN = process.env.WHATSAPP_TOKEN;
const PHONE_ID = process.env.PHONE_NUMBER_ID;
const API_VERSION = process.env.GRAPH_API_VERSION || "v23.0";

app.get("/", (_req, res) => res.send("JONATHAN-MD is running."));
app.get("/webhook", (req, res) => {
  if (req.query["hub.mode"] === "subscribe" &&
      req.query["hub.verify_token"] === VERIFY_TOKEN) {
    return res.status(200).send(req.query["hub.challenge"]);
  }
  res.sendStatus(403);
});

async function reply(to, body) {
  if (!TOKEN || !PHONE_ID) return console.error("Set WhatsApp credentials in .env");
  const response = await fetch(
    `https://graph.facebook.com/${API_VERSION}/${PHONE_ID}/messages`,
    {
      method: "POST",
      headers: {"Authorization": `Bearer ${TOKEN}`, "Content-Type": "application/json"},
      body: JSON.stringify({
        messaging_product: "whatsapp",
        recipient_type: "individual",
        to,
        type: "text",
        text: {preview_url: false, body}
      })
    }
  );
  if (!response.ok) console.error("WhatsApp API error:", await response.text());
}

app.post("/webhook", (req, res) => {
  res.sendStatus(200);
  (async () => {
    for (const entry of (req.body.entry || [])) {
      for (const change of (entry.changes || [])) {
        for (const msg of (change.value?.messages || [])) {
          if (msg.type !== "text" || !msg.from) continue;
          const text = (msg.text?.body || "").trim().toLowerCase();
          let answer = "ආයුබෝවන්! මම JONATHAN-MD Bot. උදව් සඳහා !help යවන්න.";
          if (text === "!help" || text === "help") {
            answer = "JONATHAN-MD Commands:\n!help - උදව්\n!about - Bot විස්තර";
          } else if (text === "!about" || text === "about") {
            answer = "JONATHAN-MD is a WhatsApp Cloud API demo bot.";
          }
          await reply(msg.from, answer);
        }
      }
    }
  })().catch(console.error);
});

app.listen(PORT, () => console.log(`JONATHAN-MD listening on ${PORT}`));
