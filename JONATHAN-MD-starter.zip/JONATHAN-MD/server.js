require("dotenv").config();
const express = require("express");

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
const WHATSAPP_TOKEN = process.env.WHATSAPP_TOKEN;
const PHONE_NUMBER_ID = process.env.PHONE_NUMBER_ID;
const GRAPH_API_VERSION = process.env.GRAPH_API_VERSION || "v23.0";

app.get("/", (_req, res) => res.send("JONATHAN-MD is running."));

app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token && token === VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

async function sendText(to, body) {
  if (!WHATSAPP_TOKEN || !PHONE_NUMBER_ID) {
    console.error("Missing WHATSAPP_TOKEN or PHONE_NUMBER_ID.");
    return;
  }

  const url = `https://graph.facebook.com/${GRAPH_API_VERSION}/${PHONE_NUMBER_ID}/messages`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${WHATSAPP_TOKEN}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { preview_url: false, body }
    })
  });

  if (!response.ok) {
    const details = await response.text();
    console.error("WhatsApp API error:", response.status, details);
  }
}

app.post("/webhook", async (req, res) => {
  // Acknowledge quickly; Meta retries webhook deliveries if this is slow.
  res.sendStatus(200);

  try {
    const entries = req.body.entry || [];
    for (const entry of entries) {
      for (const change of (entry.changes || [])) {
        const value = change.value || {};
        for (const message of (value.messages || [])) {
          if (!message.from || message.type !== "text") continue;

          const incoming = (message.text?.body || "").trim().toLowerCase();
          let reply = "ආයුබෝවන්! මම JONATHAN-MD Bot. උදව් සඳහා *!help* යවන්න.";

          if (incoming === "!help" || incoming === "help") {
            reply = "JONATHAN-MD Commands:\\n!help - උදව්\\n!about - Bot විස්තර";
          } else if (incoming === "!about" || incoming === "about") {
            reply = "JONATHAN-MD is a WhatsApp Cloud API demo bot.";
          }

          await sendText(message.from, reply);
        }
      }
    }
  } catch (error) {
    console.error("Webhook processing error:", error);
  }
});

app.listen(PORT, () => {
  console.log(`JONATHAN-MD listening on port ${PORT}`);
});
