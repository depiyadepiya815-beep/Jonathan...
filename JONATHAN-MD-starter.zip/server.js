const express = require("express");
const axios = require("axios");

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
const ACCESS_TOKEN = process.env.WHATSAPP_ACCESS_TOKEN;
const PHONE_NUMBER_ID = process.env.PHONE_NUMBER_ID;
const GRAPH_API_VERSION = process.env.GRAPH_API_VERSION;

app.get("/", (_req, res) => res.send("JONATHAN-MD webhook is running"));

app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

async function sendText(to, body) {
  if (!ACCESS_TOKEN || !PHONE_NUMBER_ID || !GRAPH_API_VERSION) {
    console.error("Missing WhatsApp API environment settings.");
    return;
  }

  const url = `https://graph.facebook.com/${GRAPH_API_VERSION}/${PHONE_NUMBER_ID}/messages`;
  await axios.post(url, {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to,
    type: "text",
    text: { body }
  }, {
    headers: {
      Authorization: `Bearer ${ACCESS_TOKEN}`,
      "Content-Type": "application/json"
    }
  });
}

app.post("/webhook", async (req, res) => {
  // Acknowledge Meta quickly; process incoming messages below.
  res.sendStatus(200);

  try {
    const entries = req.body.entry || [];
    for (const entry of entries) {
      for (const change of (entry.changes || [])) {
        const value = change.value || {};
        for (const message of (value.messages || [])) {
          if (message.type !== "text") continue;

          const from = message.from;
          const incoming = (message.text?.body || "").trim().toLowerCase();
          let reply = "ආයුබෝවන්! JONATHAN-MD වෙත සාදරයෙන් පිළිගනිමු. උදව් සඳහා !help යවන්න.";

          if (incoming === "!help") {
            reply = "JONATHAN-MD Commands:\\n!help - උදව්\\n!about - Bot විස්තර";
          } else if (incoming === "!about") {
            reply = "JONATHAN-MD යනු WhatsApp Cloud API මත ක්‍රියාකරන පරීක්ෂණ bot එකකි.";
          } else if (incoming.startsWith("!")) {
            reply = "එම command එක හඳුනාගත නොහැක. !help යවන්න.";
          }

          await sendText(from, reply);
        }
      }
    }
  } catch (error) {
    console.error("Webhook processing error:", error.response?.data || error.message);
  }
});

app.listen(PORT, () => {
  console.log(`JONATHAN-MD listening on port ${PORT}`);
});
