# JONATHAN-MD

Starter source code for a basic WhatsApp Cloud API webhook bot.

## What it does
- Replies to incoming individual text messages.
- `!help` shows the available commands.
- `!about` describes the bot.

This starter does **not** implement WhatsApp group messaging. It is source code only; it is not hosted or connected to a WhatsApp account.

## Requirements
- A Meta developer app and WhatsApp Cloud API setup managed by an eligible adult/business administrator.
- A public HTTPS hosting service that supports Node.js.
- The WhatsApp phone number ID, access token, and webhook verify token.

## Run locally
1. Install a current supported Node.js version.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and fill in the values privately.
4. Run `npm start`.

For Meta webhook setup, use `/webhook` as the callback path. Set the verify token to the same value as `VERIFY_TOKEN`.

Never upload `.env` or share access tokens, passwords, OTPs, QR codes, or pairing codes. Upload only `.env.example` to GitHub.
